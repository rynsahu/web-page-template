<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
    <link rel="stylesheet" href="pixelpel-css/pixelpel-upload.css">
  <body>

    <div class="centerBox">
      <div class="iconsBox">
        <div class="icon">
          <img src="pixelpel-css/images/upload.png" align="middle" class="centerIcon">
        </div>
        <p class="iconHeadig">UPLOAD IMAGE</p>
        <p class="msg">Upload the images and contribute with us.</p>
      </div>
      <div class="cntntBox">
        <!-- uploading image form -->
        <form action="upload.php" method="post" enctype="multipart/form-data">
          <div class="formCntnt">
            <input type="file" name="file" id = "chooseFileBtn">
            <input type="submit" name="submit" value="Upload Image" id="submitButton">
          </div>
        </form>

      </div>

    </div>

    <!-- php code for uploading images -->
    <?php
      //check wethere submit button is true or false
      if(isset($_POST['submit'])){
        $file = $_FILES['file'];   //getting the information about the file

        $fileName = $_FILES['file']['name'];          //name of the file
        $fileTempName = $_FILES['file']['tmp_name'];  //location of the file
        $fileError = $_FILES['file']['error'];        //checking error(0 or 1) of the file
        $fileSize = $_FILES['file']['size'];          //size of the file
        $fileType = $_FILES['file']['type'];          //type of the file

        $fileExt = explode('.', $fileName);   //exploding the file name in to 2 parts(example.jpeg)
        $fileActualExt = strtolower(end($fileExt)); //getting the file extenstion in lower case

        $allowed = array('jpg', 'jpeg', 'png');  //files allowed to upload

        //checking wethere file is image file or not.
        if(in_array($fileActualExt, $allowed)){
            if($fileError === 0){
                //file should be less then 500Mb
                if($fileSize < 500000){
                    $fileNameNew = uniqid('',true).".".$fileActualExt;  //creating unique id name for image
                    $fileDestination = 'uploads/'.$fileNameNew;         //uploading file in to the uploads folder
                    move_uploaded_file($fileTempName, $fileDestination);//changing the location of the image
                    echo "<p class='phpAlertMsg phpSuccessMsg'>Upload successful!</p>";                         // message
                }
                else{
                  echo "<p class='phpAlertMsg'>Your file is too big!</p>";
                }
            }
            else{
                echo "<p class='phpAlertMsg'>Something went wrong! please try after some time.</p>";
            }
        }
        else{
          echo "<p class='phpAlertMsg'>You can not upload file <u>.$fileActualExt</u> type! only jpg, jpeg and png is valid.</p>";
        }

      }
    ?>
  </body>
</html>
